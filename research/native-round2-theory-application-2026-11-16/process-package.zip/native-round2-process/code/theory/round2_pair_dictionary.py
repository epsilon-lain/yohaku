"""Round2 native theory: definition-paid flat pair conjunction dictionaries.
Pricing convention source: external/concept-tree-cost-9-3-9@1.
Boolean semantics and theorems: M-98718cbca95c0dc3@1.
No official AC resource code is used. Finite checks do not prove general n.
"""
from collections import Counter
from functools import lru_cache
from itertools import combinations, permutations
from pathlib import Path
import hashlib
import json
import time

ROOT = Path(__file__).resolve().parent
FREEZE_BYTES = (ROOT / "round2-pair-freeze.json").read_bytes()
FREEZE = json.loads(FREEZE_BYTES)
assert FREEZE["format"] == "native-pair-concept-theory-freeze/1"
assert FREEZE["costs"]["definition_body"] == 3

def submasks(mask):
    s = mask
    while True:
        yield s
        if s == 0:
            break
        s = (s-1) & mask

def graph_edges(n):
    return list(combinations(range(n),2))

def edge_dictionary_mask(n,pairs):
    index = {e:i for i,e in enumerate(graph_edges(n))}
    return sum(1<<index[tuple(sorted(e))] for e in pairs)

def support_union_cover_dp(n, edges, D):
    # Direct grammar semantics: any leaf is an atom or a chosen pair name.
    # Union strictly increases support when a leaf helps. Overlap is allowed.
    leaves = [1<<i for i in range(n)]
    leaves += [(1<<a)|(1<<b) for i,(a,b) in enumerate(edges) if D & (1<<i)]
    infinity = n+1
    dp = [infinity]*(1<<n)
    dp[0] = 0
    for support in range(1<<n):
        for leaf in leaves:
            nxt = support | leaf
            if nxt != support and dp[nxt] > dp[support]+1:
                dp[nxt] = dp[support]+1
    return [0]+[2*dp[T]-1 for T in range(1,1<<n)]

def matching_by_vertex_branching(n, edges, D):
    adjacency = [0]*n
    for i,(a,b) in enumerate(edges):
        if D & (1<<i):
            adjacency[a] |= 1<<b
            adjacency[b] |= 1<<a
    @lru_cache(None)
    def rec(T):
        if T == 0:
            return 0
        low = T & -T
        v = low.bit_length()-1
        remaining = T ^ low
        best = rec(remaining)
        choices = remaining & adjacency[v]
        while choices:
            w = choices & -choices
            choices ^= w
            best = max(best, 1+rec(remaining ^ w))
        return best
    return [rec(T) for T in range(1<<n)]

def star_triangle_components(n, edges, H):
    adj = [set() for _ in range(n)]
    for i,(a,b) in enumerate(edges):
        if H & (1<<i):
            adj[a].add(b)
            adj[b].add(a)
    seen = set()
    for first in range(n):
        if first in seen:
            continue
        queue = [first]
        seen.add(first)
        component = []
        while queue:
            v = queue.pop()
            component.append(v)
            for w in adj[v]:
                if w not in seen:
                    seen.add(w)
                    queue.append(w)
        size = len(component)
        if size == 1:
            continue
        edge_count = sum(len(adj[v]) for v in component)//2
        star = edge_count == size-1 and max(len(adj[v]) for v in component) == size-1
        triangle = size == 3 and edge_count == 3
        if not (star or triangle):
            return False
    return True

def submodularity_by_all_second_differences(H, ranks):
    checked = 0
    for D in submasks(H):
        unused = H ^ D
        bits = [1<<i for i in range(unused.bit_length()) if unused & (1<<i)]
        for a,b in combinations(bits,2):
            checked += 1
            lhs = ranks[D|a] + ranks[D|b]
            rhs = ranks[D] + ranks[D|a|b]
            if lhs < rhs:
                return False, checked, {"D":D,"a":a,"b":b,"lhs":lhs,"rhs":rhs}
    return True, checked, None

def semantic_profile_check(n,edges,D):
    selected = [e for i,e in enumerate(edges) if D & (1<<i)]
    profiles = set()
    for x in range(1<<n):
        original = tuple((x>>i)&1 for i in range(n))
        named = tuple(int(bool(x&(1<<a)) and bool(x&(1<<b))) for a,b in selected)
        profile = original+named
        assert profile[:n] == original
        profiles.add(profile)
    assert len(profiles) == 1<<n
    # Dropping even one atom loses information with pair-AND-only names.
    for missing in range(n):
        def reduced(x):
            return tuple((x>>i)&1 for i in range(n) if i != missing)+tuple(
                int(bool(x&(1<<a)) and bool(x&(1<<b))) for a,b in selected)
        assert reduced(0) == reduced(1<<missing)
    return len(profiles)

def analyze_size(n):
    edges = graph_edges(n)
    m = len(edges)
    records = []
    ranks = []
    targets_checked = 0
    valuation_profiles_checked = 0
    # Independent-in-method direct support-cover DP vs matching branching.
    # Both implementations are by this same author, not peer review.
    for D in range(1<<m):
        costs = support_union_cover_dp(n,edges,D)
        matching = matching_by_vertex_branching(n,edges,D)
        for T in range(1,1<<n):
            assert costs[T] == 2*(T.bit_count()-matching[T])-1, (n,D,T)
            targets_checked += 1
        ranks.append(matching[-1])
        valuation_profiles_checked += semantic_profile_check(n,edges,D)
        records.append({"dictionary_mask":D,"matching_full":matching[-1],
                        "description_cost_by_target_mask":costs})
    submod_count = 0
    hessian_checks = 0
    first_failure = None
    classification = []
    optimization_checks = 0
    candidates_examined = 0
    for H in range(1<<m):
        actual,checks,witness = submodularity_by_all_second_differences(H,ranks)
        predicted = star_triangle_components(n,edges,H)
        assert actual == predicted, (n,H,witness)
        hessian_checks += checks
        submod_count += int(actual)
        if not actual and first_failure is None:
            first_failure = {"eligible_mask":H,"witness":witness}
        classification.append(actual)
        # Freeze varied positive definition prices separately from literal3.
        for delta in FREEZE["experiments"]["definition_cost_sweep"]:
            for q in FREEZE["experiments"]["repeat_counts"]:
                best = None
                optimizers = []
                for D in submasks(H):
                    candidates_examined += 1
                    value = delta*D.bit_count()+q*(2*n-1-2*ranks[D])
                    if best is None or value < best:
                        best = value
                        optimizers = [D]
                    elif value == best:
                        optimizers.append(D)
                expected = q*(2*n-1)-max(0,2*q-delta)*ranks[H]
                assert best == expected, (n,H,delta,q,best,expected)
                assert all(D.bit_count() == ranks[D] for D in optimizers)
                optimization_checks += 1
    return {
        "n":n,"edges_in_index_order":edges,"dictionaries":1<<m,
        "nonempty_target_comparisons":targets_checked,
        "valuation_profiles_checked":valuation_profiles_checked,
        "eligible_graphs_classified":1<<m,"submodular_eligible_graphs":submod_count,
        "second_difference_tests_until_first_failure":hessian_checks,
        "first_non_submodular_witness":first_failure,
        "definition_price_reuse_optimizer_checks":optimization_checks,
        "dictionary_candidates_examined_for_optimization":candidates_examined,
        "all_dictionary_records":records,
        "eligible_submodularity_flags":classification,
        "all_assertions_passed":True,
    }

def greedy_and_counterexamples():
    spec = FREEZE["experiments"]["greedy_case"]
    n, q, delta = spec["n"], spec["repeat_count"], spec["definition_cost"]
    edges = graph_edges(n)
    H = edge_dictionary_mask(n,spec["edges"])
    index_bits = [1<<i for i in range(len(edges)) if H&(1<<i)]
    ranks = [matching_by_vertex_branching(n,edges,D)[-1] for D in range(1<<len(edges))]
    def profit(D):
        return 2*q*ranks[D]-delta*D.bit_count()
    optimum = max(profit(D) for D in submasks(H))
    orders = []
    histogram = Counter()
    for order in permutations(index_bits):
        D = 0
        steps = []
        for e in order:
            marginal = profit(D|e)-profit(D)
            steps.append({"candidate_edge_bit":e,"marginal":marginal,"accepted":marginal>0})
            if marginal > 0:
                D |= e
        assert D.bit_count() == ranks[D]
        assert 2*profit(D) >= optimum
        assert all(profit(D|e) <= profit(D) for e in index_bits if not D&e)
        histogram[profit(D)] += 1
        orders.append({"edge_bit_order":order,"selected_dictionary":D,
                       "profit":profit(D),"total_cost":q*(2*n-1)-profit(D),"steps":steps})
    middle = edge_dictionary_mask(n,[(1,2)])
    left = edge_dictionary_mask(n,[(0,1)])
    right = edge_dictionary_mask(n,[(2,3)])
    bad_marginal = profit(middle|right)-profit(middle)
    later_marginal = profit(middle|left|right)-profit(middle|left)
    assert (bad_marginal,later_marginal) == (-3,1)
    assert dict(histogram) == {1:2,2:4}
    assert optimum == 2
    # Heterogeneous target corpus: optimal definitions need not form matching.
    het = FREEZE["experiments"]["heterogeneous_boundary"]
    n2 = het["n"]
    e2 = graph_edges(n2)
    H2 = edge_dictionary_mask(n2,het["edges"])
    costs = []
    for D in submasks(H2):
        direct = support_union_cover_dp(n2,e2,D)
        total = 3*D.bit_count()+sum(t["repeats"]*direct[t["mask"]] for t in het["targets"])
        costs.append({"D":D,"cost":total})
    best = min(row["cost"] for row in costs)
    opts = [row["D"] for row in costs if row["cost"] == best]
    assert best == 10 and opts == [H2]
    assert matching_by_vertex_branching(n2,e2,H2)[-1] == 1 and H2.bit_count() == 2
    return {"P4":{"eligible_edges":spec["edges"],"q":q,"definition_cost":delta,
            "baseline":14,"optimal_profit":optimum,"optimal_total_cost":12,
            "all_six_orders":orders,"profit_histogram":dict(histogram),
            "net_marginal_from_middle":bad_marginal,
            "net_marginal_after_middle_and_left":later_marginal},
            "heterogeneous_targets":{"spec":het,"all_dictionary_costs":costs,
                 "minimum":best,"unique_optimizer":H2,"optimizer_is_matching":False}}

def main():
    start = time.monotonic()
    assert FREEZE["experiments"]["all_dictionary_graphs_n"] == [1,2,3,4,5]
    rows = []
    for n in FREEZE["experiments"]["all_dictionary_graphs_n"]:
        row = analyze_size(n)
        rows.append(row)
        print(json.dumps({k:row[k] for k in [
            "n","dictionaries","nonempty_target_comparisons","submodular_eligible_graphs",
            "second_difference_tests_until_first_failure","definition_price_reuse_optimizer_checks"
        ]}),flush=True)
    result = {
        "format":"native-round2-pair-conjunction-results/1",
        "proof_dependency":{"id":"M-98718cbca95c0dc3","revision":1},
        "external_dependencies":FREEZE["external_dependencies"],
        "freeze_sha256":hashlib.sha256(FREEZE_BYTES).hexdigest(),
        "code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "frozen_configuration":FREEZE,
        "scope":"All labelled dictionary graphs n1..5; every nonempty target; submodularity classification all eligible H n1..5; literal-cost examples and separately priced variants. Not a proof for arbitrary n.",
        "same_author_methods_are_not_independent_review":True,
        "size_results":rows,
        "explicit_counterexamples":greedy_and_counterexamples(),
        "totals":{
            "dictionaries":sum(r["dictionaries"] for r in rows),
            "nonempty_target_comparisons":sum(r["nonempty_target_comparisons"] for r in rows),
            "optimizer_checks":sum(r["definition_price_reuse_optimizer_checks"] for r in rows),
            "optimizer_candidates":sum(r["dictionary_candidates_examined_for_optimization"] for r in rows),
        },
        "elapsed_seconds":time.monotonic()-start,
        "all_assertions_passed":True,
    }
    Path("/output/round2-pair-results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"status":"passed","totals":result["totals"],
        "P4_profit_histogram":result["explicit_counterexamples"]["P4"]["profit_histogram"],
        "seconds":result["elapsed_seconds"]}),flush=True)

if __name__ == "__main__":
    main()
